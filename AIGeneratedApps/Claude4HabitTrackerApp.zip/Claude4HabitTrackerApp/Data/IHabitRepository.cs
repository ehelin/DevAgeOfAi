using HabitTracker.Models;

namespace HabitTracker.Data
{
    public interface IHabitRepository
    {
        List<Habit> GetAll();
        Habit? GetById(Guid id);
        void Add(Habit habit);
        void Update(Habit habit);
        void Delete(Guid id);
        void SaveToFile();
        void LoadFromFile();
    }
}