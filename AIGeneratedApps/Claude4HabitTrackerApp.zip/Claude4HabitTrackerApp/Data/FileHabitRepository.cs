using System.Text.Json;
using HabitTracker.Models;

namespace HabitTracker.Data
{
    public class FileHabitRepository : IHabitRepository
    {
        private readonly string _filePath;
        private List<Habit> _habits;

        public FileHabitRepository(string filePath = "habits.json")
        {
            _filePath = filePath;
            _habits = new List<Habit>();
            LoadFromFile();
        }

        public List<Habit> GetAll()
        {
            return _habits.ToList();
        }

        public Habit? GetById(Guid id)
        {
            return _habits.FirstOrDefault(h => h.Id == id);
        }

        public void Add(Habit habit)
        {
            ArgumentNullException.ThrowIfNull(habit);
            _habits.Add(habit);
            SaveToFile();
        }

        public void Update(Habit habit)
        {
            ArgumentNullException.ThrowIfNull(habit);
            
            var existingHabit = GetById(habit.Id);
            if (existingHabit != null)
            {
                var index = _habits.IndexOf(existingHabit);
                _habits[index] = habit;
                SaveToFile();
            }
        }

        public void Delete(Guid id)
        {
            var habit = GetById(id);
            if (habit != null)
            {
                _habits.Remove(habit);
                SaveToFile();
            }
        }

        public void SaveToFile()
        {
            try
            {
                var json = JsonSerializer.Serialize(_habits, new JsonSerializerOptions 
                { 
                    WriteIndented = true 
                });
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to save habits to file: {ex.Message}", ex);
            }
        }

        public void LoadFromFile()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    var json = File.ReadAllText(_filePath);
                    if (!string.IsNullOrWhiteSpace(json))
                    {
                        _habits = JsonSerializer.Deserialize<List<Habit>>(json) ?? new List<Habit>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load habits from file: {ex.Message}", ex);
            }
        }
    }
}