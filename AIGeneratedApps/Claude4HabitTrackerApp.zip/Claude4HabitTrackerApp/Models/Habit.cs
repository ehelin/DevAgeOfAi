using System;

namespace HabitTracker.Models
{
    public enum Priority
    {
        Low,
        Medium,
        High
    }

    public class Habit
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public Priority Priority { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? CompletedDate { get; set; }

        public Habit()
        {
            Id = Guid.NewGuid();
            CreatedDate = DateTime.Now;
            IsCompleted = false;
        }

        public Habit(string name, string description, Priority priority) : this()
        {
            Name = name;
            Description = description;
            Priority = priority;
        }
    }
}