using HabitTracker.Data;
using HabitTracker.Models;

namespace HabitTracker.Business
{
    public class HabitService : IHabitService
    {
        private readonly IHabitRepository _habitRepository;

        public HabitService(IHabitRepository habitRepository)
        {
            _habitRepository = habitRepository ?? throw new ArgumentNullException(nameof(habitRepository));
        }

        public List<Habit> GetAllHabits()
        {
            return _habitRepository.GetAll();
        }

        public Habit? GetHabit(Guid id)
        {
            return _habitRepository.GetById(id);
        }

        public void CreateHabit(string name, string description, Priority priority)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Habit name cannot be empty", nameof(name));

            var habit = new Habit(name.Trim(), description?.Trim() ?? string.Empty, priority);
            _habitRepository.Add(habit);
        }

        public void UpdateHabit(Guid id, string name, string description, Priority priority)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Habit name cannot be empty", nameof(name));

            var habit = _habitRepository.GetById(id);
            if (habit == null)
                throw new InvalidOperationException("Habit not found");

            habit.Name = name.Trim();
            habit.Description = description?.Trim() ?? string.Empty;
            habit.Priority = priority;

            _habitRepository.Update(habit);
        }

        public void DeleteHabit(Guid id)
        {
            _habitRepository.Delete(id);
        }

        public void MarkHabitComplete(Guid id)
        {
            var habit = _habitRepository.GetById(id);
            if (habit == null)
                throw new InvalidOperationException("Habit not found");

            if (!habit.IsCompleted)
            {
                habit.IsCompleted = true;
                habit.CompletedDate = DateTime.Now;
                _habitRepository.Update(habit);
            }
        }

        public void MarkHabitIncomplete(Guid id)
        {
            var habit = _habitRepository.GetById(id);
            if (habit == null)
                throw new InvalidOperationException("Habit not found");

            if (habit.IsCompleted)
            {
                habit.IsCompleted = false;
                habit.CompletedDate = null;
                _habitRepository.Update(habit);
            }
        }

        public List<Habit> GetHabitsByPriority(Priority priority)
        {
            return _habitRepository.GetAll().Where(h => h.Priority == priority).ToList();
        }

        public List<Habit> GetCompletedHabits()
        {
            return _habitRepository.GetAll().Where(h => h.IsCompleted).ToList();
        }

        public List<Habit> GetIncompleteHabits()
        {
            return _habitRepository.GetAll().Where(h => !h.IsCompleted).ToList();
        }
    }
}