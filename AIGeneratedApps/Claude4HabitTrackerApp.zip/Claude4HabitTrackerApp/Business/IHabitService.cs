using HabitTracker.Models;

namespace HabitTracker.Business
{
    public interface IHabitService
    {
        List<Habit> GetAllHabits();
        Habit? GetHabit(Guid id);
        void CreateHabit(string name, string description, Priority priority);
        void UpdateHabit(Guid id, string name, string description, Priority priority);
        void DeleteHabit(Guid id);
        void MarkHabitComplete(Guid id);
        void MarkHabitIncomplete(Guid id);
        List<Habit> GetHabitsByPriority(Priority priority);
        List<Habit> GetCompletedHabits();
        List<Habit> GetIncompleteHabits();
    }
}