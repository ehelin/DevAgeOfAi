using HabitTracker.Business;
using HabitTracker.Data;
using HabitTracker.Forms;

namespace HabitTracker
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            try
            {
                // Setup dependency injection
                IHabitRepository habitRepository = new FileHabitRepository();
                IHabitService habitService = new HabitService(habitRepository);

                // Run the application
                Application.Run(new MainForm(habitService));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Application failed to start: {ex.Message}", "Startup Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}