using HabitTracker.Models;

namespace HabitTracker.Forms
{
    public partial class HabitForm : Form
    {
        private TextBox txtName, txtDescription;
        private ComboBox cbPriority;
        private Button btnOK, btnCancel;
        private Label lblName, lblDescription, lblPriority;

        public string HabitName { get; private set; } = string.Empty;
        public string HabitDescription { get; private set; } = string.Empty;
        public Priority HabitPriority { get; private set; }

        public HabitForm(Habit? habit = null)
        {
            InitializeComponent();
            
            if (habit != null)
            {
                txtName.Text = habit.Name;
                txtDescription.Text = habit.Description;
                cbPriority.SelectedItem = habit.Priority.ToString();
                this.Text = "Edit Habit";
            }
            else
            {
                this.Text = "Add Habit";
            }
        }

        private void InitializeComponent()
        {
            this.Size = new Size(400, 250);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Name
            lblName = new Label
            {
                Text = "Name:",
                Location = new Point(10, 20),
                Size = new Size(80, 23)
            };

            txtName = new TextBox
            {
                Location = new Point(100, 20),
                Size = new Size(270, 23)
            };

            // Description
            lblDescription = new Label
            {
                Text = "Description:",
                Location = new Point(10, 60),
                Size = new Size(80, 23)
            };

            txtDescription = new TextBox
            {
                Location = new Point(100, 60),
                Size = new Size(270, 60),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };

            // Priority
            lblPriority = new Label
            {
                Text = "Priority:",
                Location = new Point(10, 140),
                Size = new Size(80, 23)
            };

            cbPriority = new ComboBox
            {
                Location = new Point(100, 140),
                Size = new Size(100, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cbPriority.Items.AddRange(new object[] { "Low", "Medium", "High" });
            cbPriority.SelectedIndex = 1; // Default to Medium

            // Buttons
            btnOK = new Button
            {
                Text = "OK",
                Location = new Point(210, 180),
                Size = new Size(75, 30),
                DialogResult = DialogResult.OK
            };
            btnOK.Click += BtnOK_Click;

            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(295, 180),
                Size = new Size(75, 30),
                DialogResult = DialogResult.Cancel
            };

            this.Controls.AddRange(new Control[] { lblName, txtName, lblDescription, txtDescription, lblPriority, cbPriority, btnOK, btnCancel });
            this.AcceptButton = btnOK;
            this.CancelButton = btnCancel;
        }

        private void BtnOK_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please enter a habit name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }

            HabitName = txtName.Text.Trim();
            HabitDescription = txtDescription.Text.Trim();
            if (cbPriority.SelectedItem != null)
            {
                HabitPriority = Enum.Parse<Priority>(cbPriority.SelectedItem.ToString()!);
            }
        }
    }
}