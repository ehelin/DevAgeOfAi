using System.Collections.Generic;
using HabitTracker.Models;

namespace HabitTracker.Data
{
    public interface IHabitRepository
    {
        List<Habit> LoadHabits();
        void SaveHabits(List<Habit> habits);
    }
} 