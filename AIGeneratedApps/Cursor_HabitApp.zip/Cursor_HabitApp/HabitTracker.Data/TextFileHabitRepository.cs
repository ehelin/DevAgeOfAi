using System.Collections.Generic;
using HabitTracker.Models;
using System.IO;
using System.Linq;

namespace HabitTracker.Data
{
    public class TextFileHabitRepository : IHabitRepository
    {
        private const string FileName = "habits.txt";

        public List<Habit> LoadHabits()
        {
            var habits = new List<Habit>();
            if (!File.Exists(FileName))
                return habits;

            foreach (var line in File.ReadAllLines(FileName))
            {
                var parts = line.Split('|');
                if (parts.Length != 4) continue;
                if (!int.TryParse(parts[0], out int id)) continue;
                if (!System.Enum.TryParse(parts[2], out HabitPriority priority)) continue;
                if (!bool.TryParse(parts[3], out bool isCompleted)) continue;
                habits.Add(new Habit
                {
                    Id = id,
                    Name = parts[1],
                    Priority = priority,
                    IsCompleted = isCompleted
                });
            }
            return habits;
        }

        public void SaveHabits(List<Habit> habits)
        {
            var lines = habits.Select(h => $"{h.Id}|{h.Name}|{h.Priority}|{h.IsCompleted.ToString().ToLower()}");
            File.WriteAllLines(FileName, lines);
        }
    }
} 