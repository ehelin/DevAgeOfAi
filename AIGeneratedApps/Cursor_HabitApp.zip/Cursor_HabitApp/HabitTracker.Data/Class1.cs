﻿namespace HabitTracker.Data;

public class Class1
{

}
