﻿namespace HabitTracker.Business;

public class Class1
{

}
