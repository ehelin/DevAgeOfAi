using System.Collections.Generic;
using HabitTracker.Models;
using HabitTracker.Data;
using System.Linq;

namespace HabitTracker.Business
{
    public class HabitService : IHabitService
    {
        private readonly IHabitRepository _repository;

        public HabitService(IHabitRepository repository)
        {
            _repository = repository;
        }

        public List<Habit> GetHabits()
        {
            return _repository.LoadHabits();
        }

        public void AddHabit(Habit habit)
        {
            var habits = _repository.LoadHabits();
            habit.Id = habits.Count > 0 ? habits.Max(h => h.Id) + 1 : 1;
            habits.Add(habit);
            _repository.SaveHabits(habits);
        }

        public void EditHabit(Habit habit)
        {
            var habits = _repository.LoadHabits();
            var existing = habits.FirstOrDefault(h => h.Id == habit.Id);
            if (existing != null)
            {
                existing.Name = habit.Name;
                existing.Priority = habit.Priority;
                existing.IsCompleted = habit.IsCompleted;
                _repository.SaveHabits(habits);
            }
        }

        public void DeleteHabit(int habitId)
        {
            var habits = _repository.LoadHabits();
            var toRemove = habits.FirstOrDefault(h => h.Id == habitId);
            if (toRemove != null)
            {
                habits.Remove(toRemove);
                _repository.SaveHabits(habits);
            }
        }

        public void MarkHabitComplete(int habitId)
        {
            var habits = _repository.LoadHabits();
            var habit = habits.FirstOrDefault(h => h.Id == habitId);
            if (habit != null)
            {
                habit.IsCompleted = true;
                _repository.SaveHabits(habits);
            }
        }
    }
} 