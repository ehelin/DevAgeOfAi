using System.Collections.Generic;
using HabitTracker.Models;

namespace HabitTracker.Business
{
    public interface IHabitService
    {
        List<Habit> GetHabits();
        void AddHabit(Habit habit);
        void EditHabit(Habit habit);
        void DeleteHabit(int habitId);
        void MarkHabitComplete(int habitId);
    }
} 