namespace HabitTracker.Models
{
    public enum HabitPriority
    {
        High,
        Medium,
        Low
    }

    public class Habit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public HabitPriority Priority { get; set; }
        public bool IsCompleted { get; set; }
    }
} 