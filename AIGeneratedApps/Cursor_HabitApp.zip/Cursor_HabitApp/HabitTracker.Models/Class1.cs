﻿namespace HabitTracker.Models;

public class Class1
{

}
