using System;
using System.Windows.Forms;
using HabitTracker.Models;

namespace HabitTracker.UI
{
    public class HabitDialog : Form
    {
        private TextBox txtName;
        private ComboBox cmbPriority;
        private Button btnOK;
        private Button btnCancel;
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public Habit Habit { get; private set; }

        public HabitDialog(Habit habit = null)
        {
            this.Text = habit == null ? "Add Habit" : "Edit Habit";
            this.Width = 350;
            this.Height = 200;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.AcceptButton = btnOK;
            this.CancelButton = btnCancel;
            InitializeComponents();
            if (habit != null)
            {
                txtName.Text = habit.Name;
                cmbPriority.SelectedItem = habit.Priority.ToString();
                Habit = new Habit { Id = habit.Id, IsCompleted = habit.IsCompleted };
            }
            else
            {
                Habit = new Habit();
            }
        }

        private void InitializeComponents()
        {
            Label lblName = new Label { Text = "Name:", Left = 20, Top = 20, Width = 80 };
            txtName = new TextBox { Left = 110, Top = 18, Width = 200 };
            Label lblPriority = new Label { Text = "Priority:", Left = 20, Top = 60, Width = 80 };
            cmbPriority = new ComboBox { Left = 110, Top = 58, Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbPriority.Items.AddRange(Enum.GetNames(typeof(HabitPriority)));
            cmbPriority.SelectedIndex = 0;
            btnOK = new Button { Text = "OK", Left = 110, Width = 90, Top = 100, DialogResult = DialogResult.OK };
            btnCancel = new Button { Text = "Cancel", Left = 220, Width = 90, Top = 100, DialogResult = DialogResult.Cancel };
            btnOK.Click += BtnOK_Click;
            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(lblPriority);
            this.Controls.Add(cmbPriority);
            this.Controls.Add(btnOK);
            this.Controls.Add(btnCancel);
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please enter a name.");
                this.DialogResult = DialogResult.None;
                return;
            }
            Habit.Name = txtName.Text.Trim();
            Habit.Priority = (HabitPriority)Enum.Parse(typeof(HabitPriority), cmbPriority.SelectedItem.ToString());
            this.DialogResult = DialogResult.OK;
        }
    }
} 