using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using HabitTracker.Business;
using HabitTracker.Models;

namespace HabitTracker.UI
{
    public partial class MainForm : Form
    {
        private readonly IHabitService _habitService;

        public MainForm(IHabitService habitService)
        {
            _habitService = habitService;
            InitializeComponent();
            WireUpEvents();
            LoadHabits();
        }

        private void WireUpEvents()
        {
            btnAdd.Click += BtnAdd_Click;
            btnEdit.Click += BtnEdit_Click;
            btnDelete.Click += BtnDelete_Click;
            btnMarkComplete.Click += BtnMarkComplete_Click;
            btnRefresh.Click += (s, e) => LoadHabits();
        }

        private void LoadHabits()
        {
            var habits = _habitService.GetHabits();
            dgvHabits.DataSource = habits.Select(h => new
            {
                h.Id,
                h.Name,
                Priority = h.Priority.ToString(),
                Completed = h.IsCompleted ? "Yes" : "No"
            }).ToList();
            dgvHabits.Columns["Id"].Visible = false;
        }

        private int? GetSelectedHabitId()
        {
            if (dgvHabits.SelectedRows.Count > 0)
            {
                var row = dgvHabits.SelectedRows[0];
                return Convert.ToInt32(row.Cells["Id"].Value);
            }
            return null;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var dialog = new HabitDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _habitService.AddHabit(dialog.Habit);
                LoadHabits();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            var id = GetSelectedHabitId();
            if (id == null) { MessageBox.Show("Select a habit to edit."); return; }
            var habit = _habitService.GetHabits().FirstOrDefault(h => h.Id == id);
            if (habit == null) return;
            var dialog = new HabitDialog(habit);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _habitService.EditHabit(dialog.Habit);
                LoadHabits();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var id = GetSelectedHabitId();
            if (id == null) { MessageBox.Show("Select a habit to delete."); return; }
            if (MessageBox.Show("Are you sure you want to delete this habit?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _habitService.DeleteHabit(id.Value);
                LoadHabits();
            }
        }

        private void BtnMarkComplete_Click(object sender, EventArgs e)
        {
            var id = GetSelectedHabitId();
            if (id == null) { MessageBox.Show("Select a habit to mark complete."); return; }
            _habitService.MarkHabitComplete(id.Value);
            LoadHabits();
        }
    }
} 